package onlineShop.models.products;

public abstract class BaseProduct implements Product{
    private int id;
    private String manufacturer;
    private String model;
    private double price;
    private double overallPerformance;

    protected BaseProduct(int id, String manufacturer, String model, double price, double overallPerformance) {
        this.setId(id);
        this.setManufacturer(manufacturer);
        this.setModel(model);
        this.setPrice(price);
        this.setOverallPerformance(overallPerformance);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setOverallPerformance(double overallPerformance) {
        this.overallPerformance = overallPerformance;
    }

    //    • id – int
    //        ◦ cannot be less than or equal to 0. In that case,
    //        throw IllegalArgumentException with message "Id can not be less or equal than 0."
    //    • manufacturer – String
    //        ◦ cannot be null or whitespace. In that case,
    //        throw IllegalArgumentException with message "Manufacturer can not be empty."
    //    • model – String
    //        ◦ cannot be null or whitespace. In that case,
    //        throw IllegalArgumentException with message "Model can not be empty."
    //    • price – double
    //        ◦ cannot be less than or equal to 0. In that case,
    //        throw IllegalArgumentException with message "Price can not be less or equal than 0."
    //    • overallPerformance – double
    //        ◦ cannot be less than or equal to 0. In that case,
    //        throw IllegalArgumentException with message "Overall Performance can not be less or equal than 0."

    @Override
    public int getId() {
        return 0;
    }

    @Override
    public String getManufacturer() {
        return null;
    }

    @Override
    public String getModel() {
        return null;
    }

    @Override
    public double getPrice() {
        return 0;
    }

    @Override
    public double getOverallPerformance() {
        return 0;
    }

    @Override
    public String toString() {
        return "BaseProduct{}";
    }
}
