package spaceStation.models.astronauts;

import spaceStation.models.bags.Backpack;
import spaceStation.models.bags.Bag;

public class BaseAstronaut implements Astronaut{
    private String name;
    private double oxygen;
    private Bag bag;

    protected BaseAstronaut(String name, double oxygen) {
        this.setName(name);
        this.setOxygen(oxygen);
        bag = new Backpack();
    }

    private void setName(String name) {
        this.name = name;
    }

    protected void setOxygen(double oxygen) {
        this.oxygen = oxygen;
    }

    //    • name – String
    //        ◦ If the name is null or whitespace, throw a NullPointerException with message: "Astronaut name cannot be null or empty."
    //        ◦ All names are unique
    //    • oxygen –  double
    //        ◦ The oxygen of аn astronaut
    //        ◦ If the oxygen is below 0, throw an IllegalArgumentException with message:
    // "Cannot create Astronaut with negative oxygen!"
    //    • bag – Bag
    //        ◦ A field of type Backpack

    @Override
    public String getName() {
        return null;
    }

    @Override
    public double getOxygen() {
        return 0;
    }

    @Override
    public boolean canBreath() {
        return false;
    }

    @Override
    public Bag getBag() {
        return null;
    }

    @Override
    public void breath() {

    }
}
