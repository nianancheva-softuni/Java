package spaceStation.models.planets;

import java.util.ArrayList;
import java.util.Collection;

public class PlanetImpl implements Planet{
    private String name;
    private Collection<String> items;

    public PlanetImpl(String name) {
        this.setName(name);
        items = new ArrayList<>();
    }

    public void setName(String name) {
        this.name = name;
    }

    //    • name – String
    //        ◦ If the name is null or whitespace,
    //        throw a NullPointerException with message: "Invalid name!"
    //    • items – a collection of Strings

    @Override
    public Collection<String> getItems() {
        return null;
    }

    @Override
    public String getName() {
        return null;
    }
}
